import { Home, Profile, SignIn, SignUp } from "@/pages";
import {
  HomeIcon,
  UserCircleIcon,
  ArrowRightOnRectangleIcon,
  UserPlusIcon,
  DocumentTextIcon,
} from "@heroicons/react/24/solid";

export const routes = [
  {
    icon: HomeIcon,
    name: "Return Home",
    path: "/home",
    element: <Home />,
  },
  {
    icon: DocumentTextIcon,
    name: "Bay Side News",
    href: "https://docs.google.com/document/d/1SD3WbfRFqi8XyccRLURvJbYPmz_RNEm0sF_YPiHMqmI/edit?usp=sharing",
    target: "_blank",
    element: "",
  },
];

export default routes;
