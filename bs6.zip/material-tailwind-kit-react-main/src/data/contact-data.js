import {
  StarIcon,
  PresentationChartLineIcon,
  RocketLaunchIcon,
} from "@heroicons/react/24/solid";

export const contactData = [
  {
    title: "Have a in city related question?",
    icon: StarIcon,
    description:
      "WE DO NOT. BY ANY MEANS ALLOW META GAMING TO TAKE PLACE. PLEASE MAKE SURE TO KEEP ALL IN CITY RELATED QUESTIONS.. **IN CITY**!!!",
  },
  {
    title: "Make sure to donate your cuts!",
    icon: PresentationChartLineIcon,
    description:
      "Donations to the in city bank account after every job or two is appreciated! If you help us out we will help you. Keep in mind only donate if you are INSIDE THE GANG. and are EARNING payouts.",
  },
  {
    title: "Divide the payout.",
    icon: RocketLaunchIcon,
    description:
      "Make sure you are keeping track of what jobs you do! if you hit an ALLEGED atm with a friend, make sure to cut it out evenly! Un-evenly cut payouts will be noticed and action will be taken. Don't forget your friends!",
  },
];

export default contactData;
