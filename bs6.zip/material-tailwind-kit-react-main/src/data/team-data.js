export const teamData = [
  {
    img: "/img/team-1.jpg",
    name: "Vinny B.",
    position: "O-1 | LEADER",
    socials: [
      {
        color: "",
        name: "",
      },
      {
        color: "",
        name: "",
      },
      {
        color: "",
        name: "",
      },
    ],
  },
  {
    img: "/img/team-2.jpg",
    name: "Frank J.",
    position: "O-2 | SECOND IN COMMAND",
    socials: [
      {
        color: "",
        name: "",
      },
      {
        color: "",
        name: "",
      },
      {
        color: "",
        name: "",
      },
    ],
  },
  {
    img: "/img/team-3.jpg",
    name: "Kian K.",
    position: "O-3 | TOP LINE MANAGER",
    socials: [
      {
        color: "",
        name: "",
      },
      {
        color: "",
        name: "",
      },
      {
        color: "",
        name: "",
      },
    ],
  },
  {
    img: "/img/team-4.png",
    name: "The Family",
    position: "<3 Everyone Else",
    socials: [
      {
        color: "",
        name: "",
      },
      {
        color: "",
        name: "",
      },
      {
        color: "",
        name: "",
      },
    ],
  },
];

export default teamData;
