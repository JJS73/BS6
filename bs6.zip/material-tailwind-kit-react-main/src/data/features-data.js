import {
  StarIcon,
  ArrowPathIcon,
  FingerPrintIcon,
} from "@heroicons/react/24/solid";

export const featuresData = [
  {
    color: "blue",
    title: "Family",
    icon: StarIcon,
    description:
      "One of our strongest push points is on top of the classical 'gang' term we are more then that. We are a family at the end of the day. If one bleeds we all bleed and its as simple as that.",
  },
  {
    color: "red",
    title: "Drama Free Enviroment",
    icon: ArrowPathIcon,
    description:
      "There isnt anything worse other then drama. Here at Bay Side 6iX we have a 1 Day Drama rule. If you cant settle your beef with another member in under 24 hours, you're out. Simple.",
  },
  {
    color: "teal",
    title: "Veteran's Only",
    icon: FingerPrintIcon,
    description:
      "BS6 is not new to the scene, Every member from BS6 is a certified vet in Los Santos. All of us combined make up over 20k hours in Los Santos and we highly encourage activity inside LS.",
  },
];

export default featuresData;
