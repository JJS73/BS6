export * from "@/widgets/layout/navbar";
export * from "@/widgets/layout/footer";
export * from "@/widgets/layout/simple-footer";
export * from "@/widgets/layout/page-title";
